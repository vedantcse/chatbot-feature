import DisplayPage from './DisplayPage';
export default DisplayPage;