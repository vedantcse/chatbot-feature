export const IDLE = 'IDLE';
export const IN_PROGRESS = 'IN_PROGRESS';
export const COMPLETED = 'COMPLETE';
export const FAILED = 'FAILED';
